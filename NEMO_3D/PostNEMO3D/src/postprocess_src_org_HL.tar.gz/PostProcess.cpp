/*****************************************************************************
The Jet Propulsion Laboratory (JPL) NanoElectronicMOdeling-3D
PostProcessing package.
Copyright (C) 2002 California Institute of Technology (Caltech)

This application is free software, which you can redistribute and/or modify
under the terms of the GNU Lesser General Public License as published by the
Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this library; see the file COPYING. If not, write to the
Free Software Foundation, Inc.,
59 Temple Place, Suite 330,
Boston, MA  02111-1307  USA

For additional information, please contact
  Seungwon Lee (Seungwon.Lee@jpl.nasa.gov)

Written by:  Seungwon Lee
*****************************************************************************/

#include "FakeMPI.h"
#if (defined MPI3d && !defined FAKE_MPI)
#include <mpi.h>
#endif
#include <fstream>
#include <iomanip>
#include <vector>
#include <string>
#include <complex>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "nml_dcvector.h"
#include "Coulomb.h"
#include "ReadData.h"
#include "SimpleParser.h"
//#include "DispersionUnfold.h"
using namespace std;

#define PI 3.14159265

int main(int argc, char** argv) {

  int rank=0, size=1;
#if (defined MPI3d && !defined FAKE_MPI)
  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);
#endif
  char data[123];
  int NumElectrons = 0;
  int NumHoles = 0;
  int NumAtoms = 0;
  int NumOrbitals = 0;
  int* eList;
  int* hList;
  int steps=0;

//Read Options =================================================
  vector<string> options;
  for(int i=0; i<argc; i++) options.push_back(argv[i]);
  unsigned int iopt = 0;
  bool ComputeCoulomb = false;
  bool ComputeCoulomb_new=false;
  bool dielectric=false;
  bool dot_product=false;
  bool use_density=false;
 
  while(iopt < options.size()) {
    if(options[iopt] == "--data") {
      strcpy(data,options[++iopt].c_str());
    }      
    else if(options[iopt] == "--electron") {
      NumElectrons = atoi(options[++iopt].c_str());
      eList = new int[NumElectrons];
      for(int ne=0; ne<NumElectrons; ne++){ 
         eList[ne] = atoi(options[++iopt].c_str());
      }
    }
    else if(options[iopt] == "--hole") {
      NumHoles = atoi(options[++iopt].c_str());
      hList = new int[NumHoles];
      for(int nh=0; nh<NumHoles; nh++) 
         hList[nh] = atoi(options[++iopt].c_str());
    }
    if(options[iopt] == "--coulomb") {
      ComputeCoulomb = true;
    }
    if(options[iopt] == "--hl_new") {
      ComputeCoulomb_new = true;
    }
    if(options[iopt] == "--density") {
      use_density = true;
    }
    else if(options[iopt] == "--dot") {
      dot_product = true;
    }
     else if(options[iopt] == "--dielectric") {
      dielectric = true;
      cout<<"Chose the dielectric option"<<endl;	
    }
    iopt++;
    }   

  cout.setf(ios::scientific);
  cout<<"NumElectrons, NumHoles "<<NumElectrons<<" " <<NumHoles<<endl;
  cout<<"eList: ";
  for(int ne=0; ne<NumElectrons; ne++) 
    cout<<eList[ne]<<" ";
  cout<<endl;
  cout<<"hList: ";
  for(int nh=0; nh<NumHoles; nh++) 
    cout<<hList[nh]<<" ";
  cout<<endl<<endl;
//===================================================================

//Read NEMO3D Output Files ==========================================  
  complex<double>* wf_e;
  complex<double>* wf_h;
  int* atomid;
  int* neighbor;
  double* lattice;
  double* Ee = new double[NumElectrons];
  double* Eh = new double[NumHoles];

  read_natoms_norbitals(data, &NumAtoms, &NumOrbitals, eList);

  cout<<"Number of atoms: "<<NumAtoms<<endl;
  cout<<"Number of orbitals: "<<NumOrbitals<<endl;

//Parallelization of Data ============================================
  
  int truncate = sqrt((double)size); // need to use (integer)^2 processrors. 
  int bat= NumAtoms/truncate;
  int residue = NumAtoms%truncate;
  int *myAtoms_begin,*myAtoms_end;

  myAtoms_begin = new int [truncate];
  myAtoms_end = new int [truncate];

  for(int indx = 0; indx < truncate; indx++) {

     if(indx<residue) {
        myAtoms_begin[indx] = indx*(bat+1);
        myAtoms_end[indx] = myAtoms_begin[indx] + bat + 1;
     }

     else {
        myAtoms_begin[indx] = residue*(bat+1) + (indx - residue)*bat;
        myAtoms_end[indx]   = myAtoms_begin[indx] + bat;
     }

  }

  int x1_start = 0, x1_end = 0, x2_start = 0, x2_end = 0;
  int flag = 0;
 
  for (int indx = 0; indx < truncate; indx++) {
    for (int indx2 = 0; indx2 < truncate; indx2++) {
        if(rank == (truncate*indx + indx2))  {
          flag = 1;
          x1_start = myAtoms_begin[indx]; x1_end = myAtoms_end[indx];
          x2_start = myAtoms_begin[indx2]; x2_end = myAtoms_end[indx2];
          break;
        }
    }

    if(flag == 1) break;
  }

  if (rank >= truncate*truncate) {

	  x1_start = 0; x1_end = 0;
          x2_start = 0; x2_end = 0;
         
  }

//read_data_for_postprocessing(data, NumElectrons, eList, NumHoles, hList,
        //                      &wf_e, &wf_h, &atomid, &neighbor, &lattice, &Ee, &Eh, x1_start, x1_end, x2_start, x2_end);
 
read_data_for_postprocessing_new(data, NumElectrons, eList, NumHoles, hList, &atomid, &neighbor, &lattice, &Ee, &Eh);


  for(int iatom=0; iatom<NumAtoms; iatom++) {
	
     if(atomid[iatom]==12) atomid[iatom]=0; //As atom
     else if(atomid[iatom]==10) atomid[iatom]=1; //Ga atom
     else if(atomid[iatom]==14) atomid[iatom]=2; // In atom
     else if(atomid[iatom]==6) atomid[iatom]=3; // Al atom

     if(atomid[iatom]==12) atomid[iatom]=0; //As atom
     else if(atomid[iatom]==10) atomid[iatom]=1; //Ga atom
     else if(atomid[iatom]==6) atomid[iatom]=2; // Al atom

     if(atomid[iatom] == 7) atomid[iatom]=0; // Si atom
     else if(atomid[iatom] == 8) atomid[iatom]=0; // P atom

     //else cout<<"atomid does not match with As, Ga, In, Al atom"<<endl;

  } 
//===================================================================

if(dot_product){
 Coulomb data_coulomb =
                Coulomb(NumAtoms, x1_start, x1_end, x2_start, x2_end, NumOrbitals);
		complex<double>* wf_e1;
                read_wf(data, 2, eList, &wf_e1, x1_start, x1_end, x2_start, x2_end);
                data_coulomb.get_data(wf_e1, atomid, neighbor, lattice);
	int csize=1;
    	complex<double>* local_S;
    	local_S = new complex<double>[csize];	
    	if(x1_end != 0)
		data_coulomb.dotProduct(1, 2, local_S);

complex<double>* total_S;
total_S = new complex<double>[csize];

#if (defined MPI3d && !defined FAKE_MPI)
    MPI_Reduce(local_S, total_S, csize*2, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
#else
    for(int cs=0; cs<csize; cs++) {
       total_S[cs] = local_S[cs];
    }

#endif
if (rank==0) 
       cout<<"Overlap:  "<<total_S[0]<<endl;
}



if(ComputeCoulomb_new) {

    //Computing Coulomb-Exchange energies ===============================
    	Coulomb data_coulomb =
        	Coulomb(NumAtoms, x1_start, x1_end, x2_start, x2_end, NumOrbitals);
    	//ifstream coulomb_input("coulomb.table");
    	//data_coulomb.assign_table(coulomb_input);
       	data_coulomb.assign_table1();

    	//data_coulomb.get_data(wf_e, atomid, neighbor, lattice);
        FILE* fp=fopen("exchange_parameters","r");
        float dd_cutoff=12.0;
        double dd_cutoff1=dd_cutoff;
        int use_dd_cutoff=1;
        if(fp!=NULL){
                fscanf(fp, "%i\n", &use_dd_cutoff);
                fscanf(fp, "%f\n", &dd_cutoff);
                fclose(fp);
                dd_cutoff1=dd_cutoff;
        }else{
                if(rank==0)
                        cout<<"File not found: Using default parameters. dd_cutoff=12 nm"<<endl;
        }
        if(rank==0){
                cout<<"Use dd_cutoff: "<<use_dd_cutoff<<endl;
                cout<<"dd_cutoff: "<<dd_cutoff1<<"  nm"<<endl;
        }
    int csize=1;
    double elapsed_time=0.0;
    MPI_Barrier(MPI_COMM_WORLD);
    elapsed_time=-MPI_Wtime();
    complex<double>* wf_e1;
    complex<double>* local_S;
    local_S = new complex<double>[csize];
    complex<double>* total_S;
    total_S = new complex<double>[csize];

     if(x1_end != 0) {
		read_wf(data, 2, eList, &wf_e1, x1_start, x1_end, x2_start, x2_end);
		data_coulomb.get_data(wf_e1, atomid, neighbor, lattice);
        	data_coulomb.compute_coulomb_exchange2(dd_cutoff1,data, eList, NumElectrons);
		data_coulomb.dotProduct(1, 2, local_S);
       }
    elapsed_time+=MPI_Wtime();
    complex<double>* local_coul = data_coulomb.get_H_coul();
    complex<double>* local_exch = data_coulomb.get_H_exch();
    complex<double>* total_coul;
    total_coul = new complex<double>[csize];
    complex<double>* total_exch;
    total_exch = new complex<double>[csize];

#if (defined MPI3d && !defined FAKE_MPI)
    MPI_Reduce(local_coul, total_coul, csize*2, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(local_exch, total_exch, csize*2, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(local_S, total_S, csize*2, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);	
#else
    for(int cs=0; cs<csize; cs++) {
       total_coul[cs] = local_coul[cs];
       total_exch[cs] = local_exch[cs];
       total_S[cs]=local_S[cs];	
    }
#endif
    if (rank==0) {
       cout<<endl<<"====================================================="<<endl;
       cout<<"Electron and Hole Pair: "<<endl;
       cout<<"Coulomb:  "<<setw(10)<<total_coul[0]<<endl;
       cout<<"Exchange: "<<setw(10)<<total_exch[0]<<endl;
       cout<<"Overlap:	"<<setw(10)<<total_S[0]<<endl;
       cout<<endl;
       cout<<"Time to compute a matrix element:"<<elapsed_time<<endl;
       complex<double> S_sqr=conj(total_S[0])*total_S[0];
       cout<<"Overlap Square:  "<<setw(10)<<S_sqr<<endl;			
       complex<double> exchange=(2/(1-S_sqr.real()*S_sqr.real()))*(S_sqr*total_coul[0]-total_exch[0]);
       cout<<"Exchange Energy="<<exchange<<endl;

       char filename1[200];
       if(NumElectrons==2)
                sprintf(filename1, "Coulomb_%d_%d_%d_%d", eList[0], eList[1], eList[0], eList[1]);
       else
                sprintf(filename1, "Coulomb_%d_%d_%d_%d", eList[0], eList[1], eList[2], eList[3]);
       FILE* fp1=fopen(filename1,"w");
       if(fp1!=NULL){
                fprintf(fp1, "%12.10le %12.10le\n", total_coul[0].real(), total_coul[0].imag());
                fprintf(fp1, "%12.10le %12.10le\n", total_exch[0].real(), total_exch[0].imag());
		fprintf(fp1, "%12.10le %12.10le\n", total_S[0].real(), total_S[0].imag());
		fprintf(fp1, "%12.10le %12.10le\n", exchange.real(), exchange.imag());
       }
       fclose(fp1);
   }
}

if(ComputeCoulomb) {

    //Computing Coulomb-Exchange energies ===============================
    	Coulomb data_coulomb =
        	Coulomb(NumAtoms, x1_start, x1_end, x2_start, x2_end, NumOrbitals);
    	ifstream coulomb_input("coulomb.table");
    	data_coulomb.assign_table(coulomb_input);
       	//data_coulomb.assign_table1();

    	//data_coulomb.get_data(wf_e, atomid, neighbor, lattice);
        FILE* fp=fopen("exchange_parameters","r");
        float dd_cutoff=12.0;
        double dd_cutoff1=dd_cutoff;
        int use_dd_cutoff=1;
        if(fp!=NULL){
                fscanf(fp, "%i\n", &use_dd_cutoff);
                fscanf(fp, "%f\n", &dd_cutoff);
                fclose(fp);
                dd_cutoff1=dd_cutoff;
        }else{
                if(rank==0)
                        cout<<"File not found: Using default parameters. dd_cutoff=12 nm"<<endl;
        }
        if(rank==0){
                cout<<"Use dd_cutoff: "<<use_dd_cutoff<<endl;
                cout<<"dd_cutoff: "<<dd_cutoff1<<"  nm"<<endl;
        }
    int csize=1;
    double elapsed_time=0.0;
    MPI_Barrier(MPI_COMM_WORLD);
    elapsed_time=-MPI_Wtime();
    complex<double>* wf_e1;

     if(x1_end != 0) {
		read_wf(data, 2, eList, &wf_e1, x1_start, x1_end, x2_start, x2_end);
		data_coulomb.get_data(wf_e1, atomid, neighbor, lattice);
        	data_coulomb.compute_coulomb_exchange2(dd_cutoff1,data, eList, NumElectrons);
       }
    elapsed_time+=MPI_Wtime();
    complex<double>* local_coul = data_coulomb.get_H_coul();
    complex<double>* local_exch = data_coulomb.get_H_exch();
    complex<double>* total_coul;
    total_coul = new complex<double>[csize];
    complex<double>* total_exch;
    total_exch = new complex<double>[csize];

#if (defined MPI3d && !defined FAKE_MPI)
    MPI_Reduce(local_coul, total_coul, csize*2, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(local_exch, total_exch, csize*2, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
#else
    for(int cs=0; cs<csize; cs++) {
       total_coul[cs] = local_coul[cs];
       total_exch[cs] = local_exch[cs];
    }
#endif
    if (rank==0) {
       cout<<endl<<"====================================================="<<endl;
       cout<<"Electron and Hole Pair: "<<endl;
       cout<<"Coulomb:  "<<setw(10)<<total_coul[0]<<endl;
       cout<<"Exchange: "<<setw(10)<<total_exch[0]<<endl;
       cout<<endl;
       cout<<"Time to compute a matrix element:"<<elapsed_time<<endl;

       char filename1[200];
       if(NumElectrons==2)
                sprintf(filename1, "Coulomb_%d_%d_%d_%d", eList[0], eList[1], eList[0], eList[1]);
       else
                sprintf(filename1, "Coulomb_%d_%d_%d_%d", eList[0], eList[1], eList[2], eList[3]);
       FILE* fp1=fopen(filename1,"w");
       if(fp1!=NULL){
                fprintf(fp1, "%12.10le %12.10le\n", total_coul[0].real(), total_coul[0].imag());
                fprintf(fp1, "%12.10le %12.10le\n", total_exch[0].real(), total_exch[0].imag());
       }
       fclose(fp1);
   }
}

delete [] eList; delete [] hList; delete [] Ee; delete [] Eh;
delete [] myAtoms_begin; delete [] myAtoms_end;

#if (defined MPI3d && !defined FAKE_MPI)
  MPI_Finalize();
#endif
  return 0;

}	
