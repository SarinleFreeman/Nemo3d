/*
 * The Apache Software License, Version 1.1
 * 
 * Copyright (c) 1999-2002 The Apache Software Foundation.  All rights
 * reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer. 
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:  
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 * 
 * 4. The names "Xerces" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written 
 *    permission, please contact apache\@apache.org.
 * 
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 * 
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation, and was
 * originally based on software copyright (c) 1999, International
 * Business Machines, Inc., http://www.ibm.com .  For more information
 * on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */


/*
 * $Id: AttrMapImpl.cpp,v 1.2 2002/05/21 20:15:00 tng Exp $
 */

#include "AttrMapImpl.hpp"
#include "NamedNodeMapImpl.hpp"
#include "NodeImpl.hpp"
#include "ElementImpl.hpp"

AttrMapImpl::AttrMapImpl(NodeImpl *ownerNod)
	: NamedNodeMapImpl(ownerNod)
{
	hasDefaults(false);
}

AttrMapImpl::AttrMapImpl(NodeImpl *ownerNod, NamedNodeMapImpl *defaults)
	: NamedNodeMapImpl(ownerNod)
{
	hasDefaults(false);
	if (defaults != null) 
	{
		if (defaults->getLength() > 0) 
		{
			hasDefaults(true);
			cloneContent(defaults);
		}
	} 
}

AttrMapImpl::~AttrMapImpl()
{
}

AttrMapImpl *AttrMapImpl::cloneAttrMap(NodeImpl *ownerNode_p)
{
	AttrMapImpl *newmap = new AttrMapImpl(ownerNode_p);
	newmap->cloneContent(this);
	newmap->attrDefaults = this->attrDefaults;
	return newmap;
}

NodeImpl *AttrMapImpl::removeNamedItem(const DOMString &name)
{
	NodeImpl* removed = NamedNodeMapImpl::removeNamedItem(name);

	// Replace it if it had a default value
	// (DOM spec level 1 - Element Interface)
	if (hasDefaults() && (removed != null))
	{
		AttrMapImpl* defAttrs = ((ElementImpl*)ownerNode)->getDefaultAttributes();
		AttrImpl* attr = (AttrImpl*)(defAttrs->getNamedItem(name));
		if (attr != null)
		{
			AttrImpl* newAttr = (AttrImpl*)attr->cloneNode(true);
			setNamedItem(newAttr);
		}
	}

	return removed;
}

NodeImpl *AttrMapImpl::removeNamedItemNS(const DOMString &namespaceURI, const DOMString &localName)
{
	NodeImpl* removed = NamedNodeMapImpl::removeNamedItemNS(namespaceURI, localName);

	// Replace it if it had a default value
	// (DOM spec level 2 - Element Interface)
	if (hasDefaults() && (removed != null))
	{
		AttrMapImpl* defAttrs = ((ElementImpl*)ownerNode)->getDefaultAttributes();
		AttrImpl* attr = (AttrImpl*)(defAttrs->getNamedItemNS(namespaceURI, localName));
		if (attr != null)
		{
			AttrImpl* newAttr = (AttrImpl*)attr->cloneNode(true);
			setNamedItem(newAttr);
		}
	}

	return removed;
}
